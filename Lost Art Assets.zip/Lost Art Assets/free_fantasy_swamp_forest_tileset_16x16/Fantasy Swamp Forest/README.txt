Thank you for downloading the assets!

If you have any question please email to hello@theflavare.com or discuss on itch io forum. Any question and suggest are welcome.
see our other collections in https://theflavare.itch.io/ and https://theflavare.com/

-------------
Some note:

- tileset at 16x16
- Max background height up to 25 tiles
- For Premium: Background Color Solid #d6e6f0, if you plan to use PNG type BG 3

-------------
the most back background only using 1 solid color.
